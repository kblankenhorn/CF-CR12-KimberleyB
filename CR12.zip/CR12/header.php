<!DOCTYPE html>
<html>
<head>
	<meta charset="<?php bloginfo ('charset'); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, inital=scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<meta name="description" content="<?php bloginfo('discription');?>">
	<title>Code Review 12</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Gentium+Basic:ital@1&family=Great+Vibes&display=swap" rel="stylesheet">

	
	<?php wp_head(); ?>
</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark " role="navigation">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle navigation', 'your-theme-slug' ); ?>">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- <a class="navbar-brand" href="#"></a> -->
        <?php
        wp_nav_menu( array(
            'theme_location'    => 'primary',
            'depth'             => 2, 
            'container'         => 'div',
            'container_class'   => 'collapse navbar-collapse',
            'container_id'      => 'bs-example-navbar-collapse-1',
            'menu_class'        => 'nav navbar-nav',
            'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
            'walker'            => new WP_Bootstrap_Navwalker()
        ) );
        ?>
    </div>
</nav>

